Sims 4 Updater - GUI tool for updating/repairing your The Sims 4 game
made by anadius

FAQ:

    Q: Updater doesn't run, I get some error message, what should I do?
    A: First of all Sims 4 Updater is 64-bit only, so make sure your Windows
       is 64-bit too. It's written in Python 3.10 and they dropped Windows 7
       support in 3.9, so if you have Windows 7 - update it to 8 or newer.
       And lastly make sure you have VC Redist 2015-2022 x64
       ( https://support.microsoft.com/en-us/help/2977003/the-latest-supported-visual-c-downloads )
       installed and that your anti-virus doesn't block it.

Run the Updater for full readme file.
